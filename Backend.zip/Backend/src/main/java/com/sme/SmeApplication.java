package com.sme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmeApplication.class, args);
    }

}
