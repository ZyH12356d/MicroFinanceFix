package com.sme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmeApplicationTests {

    @Test
    void contextLoads() {
    }

}
